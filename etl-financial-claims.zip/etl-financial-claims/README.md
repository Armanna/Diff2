# ETL Financials Claims

## Background
"Financials Claims" ETL serves a purpose of representing a comprehensive process that combines multiple metrics of Hippo financial statistics.

