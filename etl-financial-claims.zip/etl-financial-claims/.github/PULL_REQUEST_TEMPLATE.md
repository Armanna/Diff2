## Link to story (or tech task)

* Link to the story or other documentation

## Description

Contains description of what PR is about (it could be part of the story for example e.g.

This PR adds blue color to 'Add to cart' button as part of bigger story <link to story>:
- [x] Create 'Add to cart button' component; (Done in <link to PR>)
- [ ] Make button blue (current PR);
- [ ] Make button partly invisible (future work);
- [ ] Add unicorn icon to the button (future work);

## Wiki
If you learn something new about platform feel free to update `docs/` folder and add new information to our wiki.

If you update HTTP endpoints, please update API docs (https://hippostorehttpapi.docs.apiary.io/)

## Demo (screenshots or video)

If the PR goes with refactoring or bug-fixing we need to show how it was working _before_ and _after_
If the PR is about new feature, we only need to show what has been implemented
